This repository contains a set of utility CLIs written for personal use.

To compile CLI as binary in local:
```commandline
pip install -e .
```


To publish CLI as global:
```commandline
python setup.py sdist
sudo pip install Desktop/personal-use-clis/dist/personal-use-clis-0.1.tar.gz
```

